# Beaver Builder to Elementor export/import plugin

This plugin adds a small admin tool to:

- export Beaver Builder page content into a JSON file
- create a new draft WordPress page with Elementor-compatible metadata
- keep a fallback HTML version for basic render compatibility

## Installation

1. Upload the plugin folder to wp-content/plugins/
2. Activate Beaver Builder to Elementor Exporter Importer
3. Go to Tools > Beaver Builder to Elementor

## Export flow

1. Open Tools > Beaver Builder to Elementor
2. Select a Beaver Builder page from the list
3. Click Export JSON
4. Save the file and move it to the target site

## Import flow

1. On the new WordPress site, install and activate Elementor
2. Install this plugin
3. Go to Tools > Beaver Builder to Elementor
4. Upload the JSON file
5. A new draft page is created and Elementor metadata is attached

## Notes

- This approach is best for simpler Beaver Builder page layouts.
- Complex Beaver Builder modules and custom styling may need follow-up refinement in Elementor.
- The plugin keeps both metadata and fallback HTML so the page still has content even if visual conversion is not pixel-perfect.
